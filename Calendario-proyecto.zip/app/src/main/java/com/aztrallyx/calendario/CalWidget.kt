package com.aztrallyx.calendario

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class CalWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, CalWidget::class.java))
            for (id in ids) m.updateAppWidget(id, build(c))
        }

        private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

        fun build(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget)
            val loc = Locale("es", "MX")
            v.setTextViewText(R.id.w_head, cap(SimpleDateFormat("EEEE d 'de' MMMM", loc).format(Date())))

            val arr = JSONArray(c.getSharedPreferences("w", Context.MODE_PRIVATE).getString("items", "[]"))
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val today = cal.timeInMillis
            val lines = ArrayList<String>()
            for (i in 0 until arr.length()) {
                if (lines.size >= 4) break
                val o = arr.getJSONObject(i)
                val d = o.getLong("d")
                if (d < today) continue
                val diff = Math.round((d - today) / 86400000.0).toInt()
                val day = when (diff) {
                    0 -> "Hoy"
                    1 -> "Mañana"
                    else -> cap(SimpleDateFormat("EEE d", loc).format(Date(d)))
                }
                val t = o.optString("t")
                lines.add("${o.optString("i")} $day${if (t.isNotEmpty()) " $t" else ""} · ${o.getString("n")}")
            }
            if (lines.isEmpty()) lines.add("Sin eventos próximos")

            val ids = intArrayOf(R.id.w_l1, R.id.w_l2, R.id.w_l3, R.id.w_l4)
            for (k in ids.indices) {
                if (k < lines.size) {
                    v.setTextViewText(ids[k], lines[k])
                    v.setViewVisibility(ids[k], View.VISIBLE)
                } else v.setViewVisibility(ids[k], View.GONE)
            }

            v.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )
            return v
        }
    }
}
